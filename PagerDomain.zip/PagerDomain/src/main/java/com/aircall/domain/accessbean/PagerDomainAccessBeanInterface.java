package com.aircall.domain.accessbean;

public interface PagerDomainAccessBeanInterface {
	public void sendAlerts(String alertMessage, String serviceKey);
	public void handleTimer();
	public void incidentClosedRequest(String serviceKey);
	public void acceptAcknowledgement(String serviceKey);
}

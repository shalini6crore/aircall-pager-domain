package com.aircall.domain.accessbean;

import com.aircall.domain.ejb.PagerDomainEjb;
import com.aircall.domain.ejb.PagerDomainEjbBean;

public class PagerDomainAccessBean implements PagerDomainAccessBeanInterface{

	PagerDomainEjb ejb = PagerDomainEjbBean.getEjb();
	
	@Override
	public void sendAlerts(String alertMessage, String serviceKey) {
		ejb.sendAlerts(alertMessage, serviceKey);
	}

	@Override
	public void handleTimer() {
		ejb.handleTimer();
	}

	@Override
	public void incidentClosedRequest(String serviceKey) {
		ejb.setServiceHealthy(serviceKey);
	}

	@Override
	public void acceptAcknowledgement(String serviceKey) {
		ejb.setAcknowledgement(serviceKey);
		
	}

}

package com.aircall.domain.util;

import java.util.ArrayList;
import java.util.List;

import com.aircall.domain.transfer.Level;
import com.aircall.domain.transfer.ServiceAlertDetails;

public class PagerDomainUtil {
	
	public static ServiceAlertDetails createSampleServiceAlertDetails(String serviceKey) {
		ServiceAlertDetails details = new ServiceAlertDetails();
		
		if(serviceKey.equalsIgnoreCase("Service_New_Alert")) {
			return null;
		} else if(serviceKey.equalsIgnoreCase("Service_Duplicate_Alert")) {
			details.setAcknowledged(false);
			details.setAlertSentTime(System.currentTimeMillis() - 780000);		// timer is at 13 minutes
			details.setEscalationLevelName(Level.LEVEL_B);
			details.setServiceKey("Service_Duplicate_Alert");
			details.setAlertMsg("Service Down");
		} else if(serviceKey.equalsIgnoreCase("Service_Timed_Out_Alert_Level_B")) {
			details.setAcknowledged(false);
			details.setAlertSentTime(System.currentTimeMillis() - 960000);		// timer is at 16 minutes
			details.setEscalationLevelName(Level.LEVEL_B);
			details.setServiceKey("Service_Timed_Out_Alert_Level_B");
			details.setAlertMsg("Service Down");
		} else if(serviceKey.equalsIgnoreCase("Service_Timed_Out_Alert_HIGHEST_Level_E")) {
			details.setAcknowledged(false);
			details.setAlertSentTime(System.currentTimeMillis() - 960000);		// timer is at 16 minutes
			details.setEscalationLevelName(Level.LEVEL_E);
			details.setServiceKey("Service_Timed_Out_Alert_HIGHEST_Level_E");
			details.setAlertMsg("Service Down");
		} else if(serviceKey.equalsIgnoreCase("Timed_out_unack_service1")) {
			details.setAcknowledged(false);
			details.setAlertSentTime(System.currentTimeMillis() - 960000);		// timer is at 16 minutes
			details.setEscalationLevelName(Level.LEVEL_B);
			details.setServiceKey("Timed_out_unack_service1");
			details.setAlertMsg("Service Down");
		} else if(serviceKey.equalsIgnoreCase("Timed_out_unack_service2")) {
			details.setAcknowledged(false);
			details.setAlertSentTime(System.currentTimeMillis() - 960000);		// timer is at 16 minutes
			details.setEscalationLevelName(Level.LEVEL_C);
			details.setServiceKey("Timed_out_unack_service2");
			details.setAlertMsg("Service Down");
		} else if(serviceKey.equalsIgnoreCase("NOT_timed_out_unack_service")) {
			details.setAcknowledged(false);
			details.setAlertSentTime(System.currentTimeMillis() - 780000);		// timer is at 13 minutes
			details.setEscalationLevelName(Level.LEVEL_C);
			details.setServiceKey("NOT_timed_out_unack_service");
			details.setAlertMsg("Service Down");
		} 
		return details;
	}
	
	public static List<ServiceAlertDetails> createSampleListServiceAlertDetails() {
		List<ServiceAlertDetails> listServices = new ArrayList<ServiceAlertDetails>();
		
		
			ServiceAlertDetails details1 = new ServiceAlertDetails();
			details1.setAcknowledged(false);
			details1.setAlertSentTime(System.currentTimeMillis() - 960000);
			details1.setEscalationLevelName(Level.LEVEL_B);
			details1.setServiceKey("Timed_out_unack_service1");
			details1.setAlertMsg("Service Down");
			
			listServices.add(details1);
			ServiceAlertDetails details2 = new ServiceAlertDetails();
			
			details2.setAcknowledged(false);
			details2.setAlertSentTime(System.currentTimeMillis() - 960000);
			details2.setEscalationLevelName(Level.LEVEL_D);
			details2.setServiceKey("Timed_out_unack_service2");
			details2.setAlertMsg("Service Down");
			
			listServices.add(details2);
			ServiceAlertDetails details3 = new ServiceAlertDetails();

			details3.setAcknowledged(false);
			details3.setAlertSentTime(System.currentTimeMillis() - 780000);
			details3.setEscalationLevelName(Level.LEVEL_C);
			details3.setServiceKey("NOT_timed_out_unack_service");
			details3.setAlertMsg("Service Down");
			
			listServices.add(details3);
		
		
		return listServices;
	}
	
	public static boolean isServiceTimedOut(ServiceAlertDetails service) {
		return (System.currentTimeMillis() - service.getAlertSentTime()) >= PagerDomainConstants.FIFTEEN_MINUTES_IN_MILLIS;
	}
}

package com.aircall.domain.model;

import java.util.List;

import com.aircall.domain.handler.PersistenceHandler;
import com.aircall.domain.transfer.ServiceAlertDetails;
import com.aircall.domain.util.PagerDomainConstants;
import com.aircall.domain.util.PagerDomainUtil;

public class HandleTimerImplService {
	private static HandleTimerImplService sINSTANCE = new HandleTimerImplService();
	
	public static HandleTimerImplService getInstance() {
		return sINSTANCE;
	}
	
	public void executeHandleTimer() {
		// DB only has unhealthy services entries. Check for ones which are timed out and unacknowledged.
		// in the list, check for which ones are timed out
		// Are timed out services unacknowledged?
		// Call sendAlertsService to send new alerts for each such service
		
		// Assuming DB has a table UNHEALTHY_SERVICES where all the details about unhealthy services are stored after alerts are sent 
		
		// Fetching all service alert entries from DB where the acknowledgement is false
		List<ServiceAlertDetails> unAckServices = PersistenceHandler.getHandler().fetch(PagerDomainConstants.DB_ENTRY_UNACKNOWLEDGED);
				
		for(ServiceAlertDetails service : unAckServices) {

			if(PagerDomainUtil.isServiceTimedOut(service)) { 	// checks if it is timed out i.e. equals to or more than 15 minutes
				System.out.println("Processing timed out service --- " + service.getServiceKey());
				sendAlertsAgain(service);
			}
		}
	}
	
	private void sendAlertsAgain(ServiceAlertDetails service) {
		SendAlertsImplService.getInstance().executeSendingAlerts(service.getAlertMsg(), service.getServiceKey()); 
	}
}

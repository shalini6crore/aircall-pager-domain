package com.aircall.domain.model;

import com.aircall.domain.handler.PersistenceHandler;

public class SetServiceHealthyImplService {
	private static SetServiceHealthyImplService sINSTANCE = new SetServiceHealthyImplService();
	
	public static SetServiceHealthyImplService getInstance() {
		return sINSTANCE;
	}
	
	public void executeSetServiceHealthy(String serviceKey) {
		// remove entry from DB
		PersistenceHandler.getHandler().delete(serviceKey);
	}
}

package com.aircall.domain.exception;

public class AlertsSendingFailedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AlertsSendingFailedException(String message) {
		super(message);
	}
}

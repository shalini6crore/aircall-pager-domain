package com.aircall.domain.handler;

import java.util.List;

import com.aircall.domain.connector.PagerDomainDBConnector;
import com.aircall.domain.transfer.ServiceAlertDetails;

public class PersistenceHandler {

	private static PersistenceHandler hINSTANCE = new PersistenceHandler();

	public static PersistenceHandler getHandler() {
		return hINSTANCE;
	}

	public void add(ServiceAlertDetails serviceDetails) {
		PagerDomainDBConnector.getInstance().add(serviceDetails);
	}

	public void update(ServiceAlertDetails servDetails) {
		PagerDomainDBConnector.getInstance().update(servDetails);
	}

	public ServiceAlertDetails fetch(String serviceKey) {
		return PagerDomainDBConnector.getInstance().fetchServiceEntry(serviceKey);
	}

	public List<ServiceAlertDetails> fetch(boolean isAcknowledged) {
		String dbQuery = "SELECT * FROM UNHEALTHY_SERVICES WHERE ACKNOWLEDGED = '" + isAcknowledged + "'";
		return PagerDomainDBConnector.getInstance().fetchConditionalServiceEntries(dbQuery);
	}
	
	public void delete(String serviceKey) {
		PagerDomainDBConnector.getInstance().delete(serviceKey);
	}

}

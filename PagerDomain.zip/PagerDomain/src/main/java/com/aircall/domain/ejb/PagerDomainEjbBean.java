package com.aircall.domain.ejb;

import javax.ejb.Stateless;

import com.aircall.domain.model.DomainServicesManager;

@Stateless
public class PagerDomainEjbBean implements PagerDomainEjb {
	private static PagerDomainEjbBean ejbINSTANCE = new PagerDomainEjbBean();
	
	public static PagerDomainEjbBean getEjb() {
		return ejbINSTANCE;
	}
	
	@Override
	public void sendAlerts(String alertMessage, String serviceKey) {
		DomainServicesManager.getInstance().sendAlerts(alertMessage, serviceKey);
	}

	@Override
	public void handleTimer() {
		DomainServicesManager.getInstance().handleTimer();
	}

	@Override
	public void setServiceHealthy(String serviceKey) {
		DomainServicesManager.getInstance().setServiceHealthy(serviceKey);
	}

	@Override
	public void setAcknowledgement(String serviceKey) {
		DomainServicesManager.getInstance().setAcknowledgement(serviceKey);
		
	}

}

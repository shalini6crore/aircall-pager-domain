package com.aircall.domain.util;

import com.aircall.domain.transfer.Level;

public class PagerDomainConstants {
	public static long FIFTEEN_MINUTES_IN_MILLIS = 15 * 60 * 1000;
	public static Level HIGHEST_LEVEL = Level.LEVEL_E;
	public static Level FIRST_LEVEL = Level.LEVEL_A;
	public static boolean DB_ENTRY_UNACKNOWLEDGED = false;
	public static String ERROR_MSG_ALERT_SENT_FAILED = "No Alerts sent for ";
}

package com.aircall.domain.handler;

import java.util.ArrayList;
import java.util.List;

import com.aircall.domain.transfer.EscalationLevel;
import com.aircall.domain.transfer.Level;

public class EscalationPolicyHandler {
	
	private static EscalationPolicyHandler eINSTANCE = new EscalationPolicyHandler();
	
	public static EscalationPolicyHandler getHandler() {
		return eINSTANCE;
	}
	
	public EscalationLevel getTargetDetails(String serviceKey, Level levelType) {
		// Call Escalation policy adapter to fetch Target details (mobile numbers and emails) for given service and level
		
		EscalationLevel targetDetails = createSampleEscalationLevelTargets(serviceKey, levelType); // should be call to EP service to fetch Escalation level
		return targetDetails;
	}
	
	private EscalationLevel createSampleEscalationLevelTargets(String serviceKey, Level levelType) {
		EscalationLevel level = new EscalationLevel();
		
		List<String> targetEmails = new ArrayList<String>();
		targetEmails.add(levelType.toString() + ".developer@aircall.com");
		targetEmails.add(levelType.toString() + ".support@aircall.com");
		List<String> targetMobiles = new ArrayList<String>();
		targetMobiles.add("+33456789");
		targetMobiles.add("+33789654");

		level.setLevel(levelType);
		level.setTargetEmails(targetEmails);
		level.setTargetMobiles(targetMobiles);
		return level;
	}
}

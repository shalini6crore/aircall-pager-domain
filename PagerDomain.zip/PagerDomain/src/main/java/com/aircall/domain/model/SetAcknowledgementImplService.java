package com.aircall.domain.model;

import com.aircall.domain.handler.PersistenceHandler;
import com.aircall.domain.transfer.ServiceAlertDetails;

public class SetAcknowledgementImplService {
	private static SetAcknowledgementImplService sINSTANCE = new SetAcknowledgementImplService();
	
	public static SetAcknowledgementImplService getInstance() {
		return sINSTANCE;
	}
	
	public void setAcknowledgement(String serviceKey) {
		// update DB with acknowledged
		ServiceAlertDetails serviceDetails = new ServiceAlertDetails();
		serviceDetails.setAcknowledged(true);
		serviceDetails.setServiceKey(serviceKey);
		
		PersistenceHandler.getHandler().update(serviceDetails);
	}
}

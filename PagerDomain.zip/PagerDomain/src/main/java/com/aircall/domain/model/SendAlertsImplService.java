package com.aircall.domain.model;

import com.aircall.domain.exception.AlertsSendingFailedException;
import com.aircall.domain.handler.AlertsHandler;
import com.aircall.domain.handler.EscalationPolicyHandler;
import com.aircall.domain.handler.PersistenceHandler;
import com.aircall.domain.transfer.EscalationLevel;
import com.aircall.domain.transfer.Level;
import com.aircall.domain.transfer.ServiceAlertDetails;
import com.aircall.domain.util.PagerDomainConstants;
import com.aircall.domain.util.PagerDomainUtil;

public class SendAlertsImplService {

	private static SendAlertsImplService sINSTANCE = new SendAlertsImplService();

	public static SendAlertsImplService getInstance() {
		return sINSTANCE;
	}

	public void executeSendingAlerts(String alertMessage, String serviceKey) {
		
		// Assuming that the Service Key will be unique for each service.

		EscalationLevel escLevel = null;
		ServiceAlertDetails service = PersistenceHandler.getHandler().fetch(serviceKey);
		
		System.out.println("    " + service);

		if (null == service) {	// No entry for this service is found in DB. Alert received is new for this serviceKey
			escLevel = fetchEscalationLevel(serviceKey, PagerDomainConstants.FIRST_LEVEL); 	// Fetch First Escalation level from EP Service
			
			// New Alert for this Service. Service unhealthy, so adding the alert details in DB
			ServiceAlertDetails serviceDetails = createServiceDetails(serviceKey, alertMessage, escLevel.getLevel());
			PersistenceHandler.getHandler().add(serviceDetails);
			
		} else if (PagerDomainUtil.isServiceTimedOut(service)) {	// Service received from DB and is timedOut. Request is from Timer service

			escLevel = raiseEscalationLevel(service.getEscalationLevelName(), serviceKey);	// Raise the level to next or keep same if it is already highest
			
			service.setEscalationLevelName(escLevel.getLevel());	// Setting new Escalation Level in the Service details Object
			service.setAlertSentTime(System.currentTimeMillis());	// Setting new time (now time). Resetting timer
			
			PersistenceHandler.getHandler().update(service); // Update DB with new Alert time and next escalation level
			
		} else {	// An entry for this serviceKey exists in DB and is < 15 minutes old. Means this is another alert request for an existing unhealthy service.
			return;		// do nothing
		}

		boolean atLeastOneAlertSent = sendAlerts(escLevel, alertMessage);
		
		if(!atLeastOneAlertSent) {
			throwAlertsFailedException(serviceKey);
		}
	}
	
	private boolean sendAlerts(EscalationLevel escLevel, String alertMsg) {
		boolean isEmailAlertSent = false;
		boolean isSmsAlertSent = false;

		if (null != escLevel.getTargetMobiles() && !escLevel.getTargetMobiles().isEmpty()) {
			isSmsAlertSent = AlertsHandler.getHandler().alertBySms(escLevel.getTargetMobiles(), alertMsg);
		}
		if (null != escLevel.getTargetEmails() && !escLevel.getTargetEmails().isEmpty()) {
			isEmailAlertSent = AlertsHandler.getHandler().alertByEmail(escLevel.getTargetEmails(), alertMsg);
		}

		if (!isSmsAlertSent && !isEmailAlertSent) {
			return false;
		}
		return true;
	}

	private EscalationLevel raiseEscalationLevel(Level currentLevel, String serviceKey) {
		EscalationLevel escLevel = null;
		if (currentLevel.equals(PagerDomainConstants.HIGHEST_LEVEL)) {
			escLevel = fetchEscalationLevel(serviceKey, currentLevel); // Since level is highest, fetching same Escalation level target details (mobiles, emails) from EP
																		// Service. Assumption is that after the highest level, the targets of same highest level 
																	// should get alerts until acknowledgement occurs or service is healthy.
		} else {
			escLevel = fetchEscalationLevel(serviceKey, currentLevel.next()); // Since level is not highest, fetching next level target details (mobiles, emails) from the EP
																									// service
		}
		return escLevel;
	}
	
	private void throwAlertsFailedException(String serviceKey) {
		try {
			throw new AlertsSendingFailedException(PagerDomainConstants.ERROR_MSG_ALERT_SENT_FAILED + serviceKey);
		} catch (AlertsSendingFailedException e) {
			e.printStackTrace();
		}
	}

	protected ServiceAlertDetails createServiceDetails(String serviceKey, String alertMessage, Level escalationLevelName) {
		ServiceAlertDetails details = new ServiceAlertDetails();
		details.setAcknowledged(false);
		details.setAlertMsg(alertMessage);
		details.setAlertSentTime(System.currentTimeMillis());
		details.setEscalationLevelName(escalationLevelName);
		details.setServiceKey(serviceKey);
		return details;
	}

	private EscalationLevel fetchEscalationLevel(String serviceKey, Level levelType) {
		EscalationLevel targetDetails = EscalationPolicyHandler.getHandler().getTargetDetails(serviceKey, levelType);
		return targetDetails;
	}

	
}

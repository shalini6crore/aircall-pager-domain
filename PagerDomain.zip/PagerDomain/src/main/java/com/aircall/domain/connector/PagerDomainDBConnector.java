package com.aircall.domain.connector;

import java.util.List;

import com.aircall.domain.transfer.ServiceAlertDetails;
import com.aircall.domain.util.PagerDomainUtil;

public class PagerDomainDBConnector {

	private static PagerDomainDBConnector dbINSTANCE = new PagerDomainDBConnector();
	
	public static PagerDomainDBConnector getInstance() {
		return dbINSTANCE;
	}
	
	public ServiceAlertDetails fetchServiceEntry(String serviceKey) {
		// Call Persistence adapter to fetch entry for the given serviceKey
		ServiceAlertDetails serviceDetailsFromDB = PagerDomainUtil.createSampleServiceAlertDetails(serviceKey); // should be the real call to persistence adapter
		return serviceDetailsFromDB;
	}
	
	public List<ServiceAlertDetails> fetchConditionalServiceEntries(String condition) {
		// Call persistence adapter to fetch entries based on the given condition.
		List<ServiceAlertDetails> services = PagerDomainUtil.createSampleListServiceAlertDetails(); // should be the real call to persistence adapter
		return services;
	}
	
	public void update(ServiceAlertDetails serviceDetails) {
		// Assuming the persistence service handles null values and updates only values which are provided, call Persistence adapter
		System.out.println("Service - " + serviceDetails.getServiceKey() + " updated in UNHEALTHY_SERVICES table in DB.");
		System.out.println("Updated Entry --- " + serviceDetails);
	}
	
	public void add(ServiceAlertDetails serviceDetails) {
		// Call Persistence service to add service details to the UNHEALTHY_SERVICES table in DB
		System.out.println("New service alert added to UNHEALTHY_SERVICES table in DB.");
		System.out.println("Entry --- " + serviceDetails);
	}
	
	public void delete(String serviceKey) {
		// Calls db to delete entry for this service - ServiceKey
		System.out.println("Entry for service " + serviceKey + " deleted from DB. Service now healthy");
	}
}

package com.aircall.domain.handler;

import java.util.List;

public class AlertsHandler {
	
	private static AlertsHandler aINSTANCE = new AlertsHandler();
	
	public static AlertsHandler getHandler() {
		return aINSTANCE;
	}
	
	public boolean alertByEmail(List<String> emails, String alertMessage) {
		// Here, make a call to real emails sending service to send email alerts
		System.out.println("Email Alerts sent to " + emails);
		return true;
	}
	
	public boolean alertBySms(List<String> mobiles, String alertMessage) {
		// Here, make a call to real sms sending service to send sms alerts
		System.out.println("SMS Alerts sent to " + mobiles);
		return true;
	}
}

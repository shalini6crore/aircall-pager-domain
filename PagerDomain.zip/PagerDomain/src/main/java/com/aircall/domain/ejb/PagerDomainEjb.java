package com.aircall.domain.ejb;
import javax.ejb.Remote;

@Remote
public interface PagerDomainEjb {
	
	public void sendAlerts(String alertMessage, String serviceKey);
	public void handleTimer();
	public void setServiceHealthy(String serviceKey);
	public void setAcknowledgement(String serviceKey);
}

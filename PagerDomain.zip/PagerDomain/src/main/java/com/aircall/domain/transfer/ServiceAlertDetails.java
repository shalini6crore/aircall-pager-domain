package com.aircall.domain.transfer;

public class ServiceAlertDetails {
	
	private String serviceKey;
	private String alertMsg;
	private Level escalationLevelName;
	private long alertSentTime;
	private boolean isAcknowledged;
	
	public String getServiceKey() {
		return serviceKey;
	}
	public void setServiceKey(String serviceKey) {
		this.serviceKey = serviceKey;
	}
	public Level getEscalationLevelName() {
		return escalationLevelName;
	}
	public void setEscalationLevelName(Level escalationLevelName) {
		this.escalationLevelName = escalationLevelName;
	}
	public long getAlertSentTime() {
		return alertSentTime;
	}
	public void setAlertSentTime(long alertSentTime) {
		this.alertSentTime = alertSentTime;
	}
	public boolean isAcknowledged() {
		return isAcknowledged;
	}
	public void setAcknowledged(boolean isAcknowledged) {
		this.isAcknowledged = isAcknowledged;
	}
	public String getAlertMsg() {
		return alertMsg;
	}
	public void setAlertMsg(String alertMsg) {
		this.alertMsg = alertMsg;
	}
	@Override
	public String toString() {
		return "ServiceAlertDetails [serviceKey=" + serviceKey + ", alertMsg=" + alertMsg + ", escalationLevelName=" + escalationLevelName + ", alertSentTime=" + alertSentTime + ", isAcknowledged="
				+ isAcknowledged + "]";
	}
	
}

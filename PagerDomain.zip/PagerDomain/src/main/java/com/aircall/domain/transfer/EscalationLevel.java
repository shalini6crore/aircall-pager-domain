package com.aircall.domain.transfer;

import java.util.List;

public class EscalationLevel {
	private Level level;
	private List<String> targetMobiles;
	private List<String> targetEmails;
	
	public Level getLevel() {
		return level;
	}
	public void setLevel(Level level) {
		this.level = level;
	}
	public List<String> getTargetMobiles() {
		return targetMobiles;
	}
	public void setTargetMobiles(List<String> targetMobiles) {
		this.targetMobiles = targetMobiles;
	}
	public List<String> getTargetEmails() {
		return targetEmails;
	}
	public void setTargetEmails(List<String> targetEmails) {
		this.targetEmails = targetEmails;
	}
}

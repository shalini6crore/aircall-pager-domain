package com.aircall.domain.model;

public class DomainServicesManager {
	
	private static final DomainServicesManager INSTANCE = new DomainServicesManager();
	
	public static DomainServicesManager getInstance() {
		return INSTANCE;
	}
	
	public void sendAlerts(String alertMessage, String serviceKey) {
		SendAlertsImplService.getInstance().executeSendingAlerts(alertMessage, serviceKey);
	}
	
	public void handleTimer() {
		HandleTimerImplService.getInstance().executeHandleTimer();
	}
	
	public void setServiceHealthy(String serviceKey) {
		SetServiceHealthyImplService.getInstance().executeSetServiceHealthy(serviceKey);
	}

	public void setAcknowledgement(String serviceKey) {
		SetAcknowledgementImplService.getInstance().setAcknowledgement(serviceKey);
		
	}
}

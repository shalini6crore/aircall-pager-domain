package com.aircall.domain.transfer;

public enum Level {
	LEVEL_A, LEVEL_B, LEVEL_C, LEVEL_D, LEVEL_E;
	
	public Level next() {
		return values()[ordinal() + 1];
	}
}

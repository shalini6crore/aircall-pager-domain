package com.aircall.domain.model;

import org.junit.Test;

public class SendAlertsImplServiceTest {

	SendAlertsImplService service = new SendAlertsImplService();

	/**
	 *  Tests SendAlertsImplService for a new alert for a service that doesn't exist in DB. Means it's unhealthy now.
	 *  Should add the alert.
	 */
	@Test
	public void test_sending_alerts_for_new_service_entry() {
		String serviceKey = "Service_New_Alert"; // For this service, DBConnector returns null. For the sake of testing.
		String alertMessage = "Chat service down";

		System.out.println("ALERTS SHOULD BE SENT. NEW ENTRY IN DB.");
		service.executeSendingAlerts(alertMessage, serviceKey);
		System.out.println("---------------------------------------------------------------------------------------------");
	}

	/**
	 *  Tests SendAlertsImplService for request from timer service. Should keep the Level same since testing for service that already has highest Level.
	 *  Assuming five levels are there. Level_A, Level_B ... Level_E
	 *  Should reset the alert time in DB. Means resetting timer.
	 */
	@Test
	public void test_sending_alert_for_timed_out_service_highest_level() {
		String serviceKey = "Service_Timed_Out_Alert_HIGHEST_Level_E"; // For this service, DBConnector returns existing entry from DB which has highest level
																		// For the sake of testing.
		String alertMessage = "Chat service down";

		System.out.println("ALERTS SHOULD BE SENT. UPDATE ENTRY IN DB. LEVEL SHOULD BE SAME AS LEVEL_E. TIMER(ALERTTIME) SHOULD BE SET TO NOW TIME");
		service.executeSendingAlerts(alertMessage, serviceKey);
		System.out.println("---------------------------------------------------------------------------------------------");

	}

	/**
	 *  Tests SendAlertsImplService for request from timer service. Should escalate Level.
	 *  Assuming five levels are there. Level_A, Level_B ... Level_E
	 *  Should reset the alert time in DB. Means resetting timer.
	 */
	@Test
	public void test_sending_alert_for_timed_out_service() {
		String serviceKey = "Service_Timed_Out_Alert_Level_B"; // For this service, DBConnector returns existing entry from DB which has LEVEL B
																// For the sake of testing.
		String alertMessage = "Chat service down";

		System.out.println("ALERTS SHOULD BE SENT. UPDATE ENTRY IN DB. LEVEL SHOULD BE INCREMENTED TO NEXT. TIMER(ALERTTIME) SHOULD BE SET TO NOW TIME");
		service.executeSendingAlerts(alertMessage, serviceKey);
		System.out.println("---------------------------------------------------------------------------------------------");

	}

	/**
	 *  Tests SendAlertsImplService when an alert for duplicate service is received.
	 *  Duplicate means there's already an entry for this service in DB and it's less than 15 minutes. 
	 *  So, should do nothing.
	 */
	@Test
	public void test_sending_alert_for_same_service() {
		String serviceKey = "Service_Duplicate_Alert"; 		// For this service, DBConnector returns existing entry from DB which has alert time less than 15 min from now
																// For the sake of testing.
		String alertMessage = "Service down";

		service.executeSendingAlerts(alertMessage, serviceKey);
		System.out.println("Should do nothing");
		System.out.println("---------------------------------------------------------------------------------------------");
	}
}

package com.aircall.domain.model;

import org.junit.Test;

public class SetAcknowledgementImplServiceTest {
	SetAcknowledgementImplService service = new SetAcknowledgementImplService();
	
	/**
	 *  Tests SetAcknowledgementImplService. Is called when incident closed request is recieved by PagerDomain.
	 *  Should set isAcknowledged to true in DB. Should not do anything.
	 */
	@Test
	public void set_acknowledgement_update_in_db() {
		String serviceKey = "Service_to_be_acknowledged";
		service.setAcknowledgement(serviceKey);
		System.out.println("Assuming DB doesn't update the table with fields that are not provided. In this case, we are sending serviceKey to identify the alert entry and isAcknowledged to set true only. DB should not update any other field.");
		System.out.println("isAcknowledged set to TRUE");
	}
}

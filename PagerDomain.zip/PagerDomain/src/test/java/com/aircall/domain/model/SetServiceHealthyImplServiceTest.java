package com.aircall.domain.model;

import org.junit.Test;

public class SetServiceHealthyImplServiceTest {
	SetServiceHealthyImplService service = new SetServiceHealthyImplService();
	
	/**
	 * Tests SetServiceHealthyImplService. Removes the entry for this service from the UNHEALTHY_SERVICES table in DB.
	 * Means service is now healthy.
	 */
	@Test
	public void test_set_service_healthy_when_incident_closed() {
		String serviceKey = "Service_Closed_Incident";
		service.executeSetServiceHealthy(serviceKey);
	}
}

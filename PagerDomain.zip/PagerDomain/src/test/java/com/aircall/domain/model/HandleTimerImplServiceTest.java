package com.aircall.domain.model;

import org.junit.Test;

public class HandleTimerImplServiceTest {
	HandleTimerImplService service = new HandleTimerImplService();
	
	/**
	 *  Tests HandleTimerImplService. Should fetch only unacknowldeged service entries from DB.
	 *  Should only send alerts again to the timed out services.
	 *  Should Raise the Escalation level and reset the time.
	 */
	@Test
	public void test_handle_timer_filters_sends_alerts_for_only_timed_out_services() {
		System.out.println("SHOULD FETCH ENTRIES FROM DB WITH ISACKNOWLEDGED SET TO FALSE.");
		System.out.println("SHOULD SEND ALERTS FOR ONLY TIMEDOUT SERVICES. SEND ALERTS TO ESCALATED LEVEL TARGETS");
		System.out.println("SHOULD UPDATE DB WITH ESCALATED LEVEL, SET ALERTTIME TO NOW");
		System.out.println("-----------------------------------------------------------------------------------------");
		service.executeHandleTimer();
	}
}
